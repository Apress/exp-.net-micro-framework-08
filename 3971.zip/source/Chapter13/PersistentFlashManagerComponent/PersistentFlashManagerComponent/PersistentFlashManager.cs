﻿using System;
using System.IO;
using System.Reflection;
using Microsoft.SPOT.Emulator.Memory;

namespace Kuehner.SPOT.Emulator
{
    public class PersistentFlashManager : FlashManager
    {
        private readonly string flashPath;

        public PersistentFlashManager()
        {
            //the file name of the flash file is the same as
            //the current emulator executable but with .flash extension
            //so every emulator has its own flash file
            string emulatorPath = Assembly.GetEntryAssembly().GetModules()[0].FullyQualifiedName;
            this.flashPath = Path.ChangeExtension(emulatorPath, ".flash");
        }

        public override void InitializeComponent()
        {
            base.InitializeComponent();
            //reading from file
            if (File.Exists(this.flashPath))
            {
                using (FileStream stream = File.OpenRead(this.flashPath))
                {
                    //only read if file size matches size of flash
                    if (stream.Length == this._size) 
                        stream.Read(this._memory, 0, (int)this._size);
                }
            }
        }

        public override void UninitializeComponent()
        {
            //writing to file
            using (FileStream stream = File.OpenWrite(this.flashPath))
                stream.Write(this._memory, 0, (int)this._size);
            //frees the memory so it needs to be called after persisting
            base.UninitializeComponent();
        }
    }
}
