﻿using System;
using Microsoft.SPOT;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;

namespace SocketUdpClientSample
{
    public class Program
    {
        private const string dottedServerIPAddress = "127.0.0.1";
        //use 255.255.255.255 for a broadcast
        private const int port = 2000;

        public static void Main()
        {
            using (Socket clientSocket = new Socket(AddressFamily.InterNetwork,
                                                    SocketType.Dgram,
                                                    ProtocolType.Udp))
            {
                // Addressing
                IPHostEntry entry = Dns.GetHostEntry(dottedServerIPAddress);
                IPAddress ipAddress = entry.AddressList[0];
                IPEndPoint serverEndPoint = new IPEndPoint(ipAddress, port);

                // Sending
                byte[] messageBytes = Encoding.UTF8.GetBytes("Hello World!");
                clientSocket.SendTo(messageBytes, serverEndPoint);
            }// the socket will be closed here
        }
    }
}
