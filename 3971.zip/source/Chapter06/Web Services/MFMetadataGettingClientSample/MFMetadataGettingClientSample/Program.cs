using System;
using Dpws.Client;
using Dpws.Client.Discovery;
using Ws.Services.Utilities;

namespace MFMetadataGettingClientSample
{
    public class Program
    {
        public static void Main()
        {
            using (MetadataGettingClient client = new MetadataGettingClient())
            {
                client.PrintMetadataInfo();
            }
        }
    }
}
