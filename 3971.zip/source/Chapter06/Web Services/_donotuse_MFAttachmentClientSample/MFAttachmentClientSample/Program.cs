﻿using System;
using System.Ext.IO;
using Ws.Services.Utilities;

namespace MFAttachmentClientSample
{
    public class Program
    {
        public static void Main()
        {
            // Set debugging preferences
            Debug.Tracing = true;

            // Discover a one way OP service
            MyAttachmentServiceController controller = MyAttachmentServiceController.FindFirst();
            if (controller != null)
            {
                // Service found, send the buffer to the device
                // Create a buffer and fill with binary data
                // This could be a image or other binary large objects (BLOB)
                byte[] buffer = new byte[256];
                for(int i = 0; i < buffer.Length; ++i)
                    buffer[i] = (byte)i;
                // The attachment is expected as stream with data,
                // so create a memory stream to provide the buffer data
                MemoryStream ms = new MemoryStream(buffer);
                controller.ProvideMyData(ms);
            }
        }
    }
}
