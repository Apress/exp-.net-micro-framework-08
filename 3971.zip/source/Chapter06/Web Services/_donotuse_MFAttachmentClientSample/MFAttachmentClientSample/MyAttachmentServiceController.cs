﻿using System;
using System.Ext;
using System.Ext.IO;
using System.Ext.Xml;
using Ws.Services.Utilities;
using Dpws.Client;
using Dpws.Client.Transport;
using Dpws.Client.Discovery;
using Ws.Services.Soap;
using Ws.Services.Mtom;

namespace MFAttachmentClientSample
{
    public class MyAttachmentServiceController : DpwsClient
    {
        const string c_namespaceUri = "http://schemas.sample.org/AttachmentService";
        const string c_namespacePrefix = "attach";
        const string c_serviceTypeName = "AttachmentServiceType";

        private readonly string serviceEndpointAddress;

        private MyAttachmentServiceController(string serviceEndpointAddress)
        {
            this.serviceEndpointAddress = serviceEndpointAddress;
        }

        public void ProvideMyData(MemoryStream attachmentStream)
        {
            if (attachmentStream == null)
                throw new ArgumentNullException("attachmentStream");
            // Create HttpClient and send request
            byte[] request = BuildProvideMyDataRequest(attachmentStream);

            Debug.Print("Sending Request:");
            //Debug.Print(request);
            DpwsHttpClient httpClient = new DpwsHttpClient();

            httpClient.SendRequest(request, // soap message
                                   this.serviceEndpointAddress, // endpoint address
                                   true, //is one way
                                   false // is chunked
                                   );
        }


        private byte[] BuildProvideMyDataRequest(MemoryStream attachmentStream)
        {
            MemoryStream soapStream = new MemoryStream();
            XmlWriter xmlWriter = XmlWriter.Create(soapStream);

            // Write processing instructions and root element
            xmlWriter.WriteProcessingInstruction("xml", "version='1.0' encoding='UTF-8'");
            xmlWriter.WriteStartElement("soap", "Envelope", "http://www.w3.org/2003/05/soap-envelope");

            // Write namespaces
            xmlWriter.WriteAttributeString("xmlns",
                                           "wsa",
                                           null,
                                           DpwsClient.Namespaces.GetNamespace("wsa"));
            xmlWriter.WriteAttributeString("xmlns",
                                           "xop",
                                           null,
                                           DpwsClient.Namespaces.GetNamespace("xop"));
            // Write our namespace
            xmlWriter.WriteAttributeString("xmlns",
                                           c_namespacePrefix,
                                           null,
                                           c_namespaceUri);

            // Write header
            xmlWriter.WriteStartElement("soap", "Header", null);
            xmlWriter.WriteStartElement("wsa", "To", null);
            xmlWriter.WriteString(this.serviceEndpointAddress);
            xmlWriter.WriteEndElement(); // End To
            // Action indicates the desired operation to execute
            xmlWriter.WriteStartElement("wsa", "Action", null);
            xmlWriter.WriteString(c_namespaceUri + "/" +
                                  "ProvideData");
            xmlWriter.WriteEndElement(); // End Action
            xmlWriter.WriteStartElement("wsa", "From", null);
            xmlWriter.WriteStartElement("wsa", "Address", null);
            xmlWriter.WriteString(this.EndpointAddress);
            xmlWriter.WriteEndElement(); // End Address
            xmlWriter.WriteEndElement(); // End From
            xmlWriter.WriteStartElement("wsa", "MessageID", null);
            xmlWriter.WriteString("urn:uuid:" + Guid.NewGuid());
            xmlWriter.WriteEndElement(); // End MessageID
            xmlWriter.WriteEndElement(); // End Header

            // write body
            xmlWriter.WriteStartElement("soap", "Body", null);
            xmlWriter.WriteStartElement("attach", "ProvideMyDataRequest", null);
            xmlWriter.WriteStartElement("attach", "MyData", null);
            xmlWriter.WriteStartElement("xop", "Include", null);
            xmlWriter.WriteAttributeString("href", "cid:0@body");
            xmlWriter.WriteString("");
            xmlWriter.WriteEndElement(); // End Include
            xmlWriter.WriteEndElement(); // End MyData
            xmlWriter.WriteEndElement(); // End ProvideMyDataRequest
            xmlWriter.WriteEndElement(); // End Body

            xmlWriter.WriteEndElement();

            // Create return buffer and close writer
            xmlWriter.Flush();
            byte[] soapBuffer = soapStream.ToArray();
            xmlWriter.Close();

            // Clear the MTOM body parts collection
            this.BodyParts = new WsMtomBodyParts();

            // Create and store SOAP body part
            // The DPWS standard requires the soap envelope to be the first body part
            WsMtomBodyPart soapBodyPart = new WsMtomBodyPart();
            soapBodyPart.Content = soapStream;
            soapBodyPart.ContentID = "<soap@soap>";
            soapBodyPart.ContentTransferEncoding = "binary";
            soapBodyPart.ContentType = "application/xop+xml;charset=UTF-8;type=\"application/soap+xml\"";
            this.BodyParts.Add(soapBodyPart);

            // Create and store attachment body part
            WsMtomBodyPart attachBodyPart = new WsMtomBodyPart();
            attachBodyPart.Content = attachmentStream;
            attachBodyPart.ContentID = "<0@body>";
            attachBodyPart.ContentTransferEncoding = "binary";
            attachBodyPart.ContentType = "application/octet-stream";
            this.BodyParts.Add(attachBodyPart);

            // Set message type so the HTTP processor knows we are sending MTOM
            //this.MessageType = WsMessageType.Mtom;

            // Return null since our response is MTOM
            return CreateMessage(this.BodyParts);
        }

        public static MyAttachmentServiceController FindFirst()
        {
            DpwsClient client = new DpwsClient(); // initializing

            Debug.Print("Discovering service devices...");
            // Define search criterias
            // We are looking for devices with a AttachmentServiceType service
            DpwsServiceType serviceType = new DpwsServiceType();
            serviceType.NamespaceUri = c_namespaceUri;
            serviceType.Prefix = c_namespacePrefix;
            serviceType.TypeName = c_serviceTypeName;
            DpwsServiceTypes filters = new DpwsServiceTypes();
            filters.Add(serviceType);
            // probe for devices
            DpwsDiscoveryClient disco = new DpwsDiscoveryClient();
            DpwsProbeMatches probeMatches = disco.Probe(filters);
            if (probeMatches != null && probeMatches.Count > 0)
            {
                // Remember transport address
                string serviceTransportAddress = probeMatches[0].XAddrs[0];
                // Reqest metadata to get the desired service and its ID
                DpwsMexClient mexClient = new DpwsMexClient();
                DpwsMetadata metadata = mexClient.Get(serviceTransportAddress);
                // Check host service
                if (metadata.Host != null) // has host service
                {
                    if (metadata.Host.ServiceTypes.Contains(c_serviceTypeName))
                        return new MyAttachmentServiceController(metadata.Host.Address.AbsoluteUri);
                }
                // Check hosted services
                if (metadata.HostedServices != null)
                {
                    foreach (DpwsMexHostedService hostedService in metadata.HostedServices)
                    {
                        if (hostedService.ServiceTypes.Contains(c_serviceTypeName))
                            return new MyAttachmentServiceController(hostedService.Address.AbsoluteUri);
                    }
                }
            }
            Debug.Print("No service found.");
            return null;
        }

        public byte[] CreateMessage(WsMtomBodyParts bodyParts)
        {
            if (bodyParts == null)
            {
                throw new ArgumentNullException("Mtom body parts collection must not be null.");
            }
            if (bodyParts.Count == 0)
            {
                throw new ArgumentException("Mtom bodyParts must at least contain a soap message body part.");
            }
            if (bodyParts.Boundary == null)
            {
                throw new ArgumentNullException("Boundary", "Must not be null");
            }
            this.m_buffer = new byte[this.m_growSize];
            this.m_curPos = 0;
            this.m_length = 0;
            if (bodyParts.Boundary == null)
            {
                this.m_bodyParts.Boundary = Guid.NewGuid().ToString() + '-' + Guid.NewGuid().ToString().Substring(0, 33);
            }
            else
            {
                this.m_bodyParts.Boundary = bodyParts.Boundary;
            }
            if (bodyParts.Start == null)
            {
                this.m_bodyParts.Start = bodyParts[0].ContentID;
            }
            else
            {
                this.m_bodyParts.Start = bodyParts.Start;
            }
            this.WriteLine("--" + bodyParts.Boundary);
            for (int i = 0; i < bodyParts.Count; i++)
            {
                this.WriteLine("Content-Type: " + bodyParts[i].ContentType);
                this.WriteLine("Content-Transfer-Encoding: " + bodyParts[i].ContentTransferEncoding);
                this.WriteLine("Content-ID: " + bodyParts[i].ContentID);
                this.WriteLine("");
                new string(this.m_utf8Encoding.GetChars(bodyParts[i].Content.ToArray()));
                this.WriteBytes(bodyParts[i].Content.ToArray());
                this.WriteLine("");
                if (i == (bodyParts.Count - 1))
                {
                    this.WriteString("--" + bodyParts.Boundary + "--");
                }
                else
                {
                    this.WriteLine("--" + bodyParts.Boundary);
                }
            }
            byte[] tempBuff = new byte[this.m_length];
            Array.Copy(this.m_buffer, tempBuff, this.m_length);
            return tempBuff;
        }
    }
}
