﻿using System;
using Microsoft.SPOT;
using System.Ext;

namespace NewGuidSample
{
    public class Program
    {
        public static void Main()
        {
            Debug.Print("New GUID: " + Guid.NewGuid());
        }
    }
}
