﻿using System;
using Dpws.Device.Services;
using Ws.Services;
using Ws.Services.WsaAddressing;
using Ws.Services.Utilities;
using Ws.Services.Xml;
using Ws.Services.Mtom;

namespace MFAttachmentDeviceSample
{
    public class AttachmentService : DpwsHostedService
    {
        public AttachmentService()
        {
            // The client filters devices when probing using the ServiceTypeName property
            this.ServiceTypeName = "AttachmentServiceType";
            // Add a unique namespace for our service
            this.ServiceNamespace = new WsXmlNamespace("attach", // prefix
                                                       "http://schemas.sample.org/AttachmentService"); // URI
            // Unique ID to access the service
            this.ServiceID = "urn:uuid:93252386-0724-c8ca-bd31-000000732d93";
            WsServiceOperation operation =
                     new WsServiceOperation(this.ServiceNamespace.Prefix,       // prefix
                                            this.ServiceNamespace.NamespaceURI, // namespace
                                            "ProvideMyData");               // operation method name
            this.ServiceOperations.Add(operation);
        }

        public byte[] ProvideMyData(WsWsaHeader header, WsXmlDocument envelope)
        {
            WsXmlNode node = envelope.SelectSingleNode("Body/TwoWayAttachmentRequest/Param/Include", false);

            string cid = "<" + node.Attributes[0].Value.Substring(4) + ">";
            Debug.Print("");
            Debug.Print("Attachment received. href = " + node.Attributes[0].Value);
            int bodyPartIndex = this.BodyParts.IndexOf(cid);
            //if (bodyPartIndex  < 0)
              //  return fault.RaiseFault(header, WsExceptionFaultType.XmlException, "Required body part \"" + tempNode.Attributes[0] + "\" in missing.");

            WsMtomBodyPart bodyPart = this.BodyParts[bodyPartIndex];
            Debug.Print("Attachment size: " + bodyPart.Content.Length);
            Debug.Print("Content ID: " + bodyPart.ContentID);
            Debug.Print("Content type: " + bodyPart.ContentType);
            Debug.Print("Content transfer encoding: " + bodyPart.ContentTransferEncoding);
            Debug.Print("");

            return new byte[0]; // no response it is a one way operation
        }
    }
}
