﻿using System;
using System.Threading;
using Ws.Services.Xml;
using Ws.Services.Utilities;
using Dpws.Device;
using Dpws.Device.Services;

namespace MFAttachmentDeviceSample
{
    public class Program
    {
        public static void Main()
        {
            // Set debugging preferences
            Debug.Tracing = true;

            // Let clients identify this device
            Device.EndpointAddress = "urn:uuid:2ac54f29-0900-c8ca-84c3-0000006d39bd";
            // Add service as hosted service
            Device.HostedServices.Add(new AttachmentService());

            // Metadata
            // Model
            Device.ThisModel.Manufacturer = "Apress, Inc.";
            Device.ThisModel.ManufacturerUrl = "http://www.apress.com/";
            Device.ThisModel.ModelName = "AttachmentModel";
            Device.ThisModel.ModelNumber = "12345";
            Device.ThisModel.ModelUrl = "http://www.apress.com/";
            Device.ThisModel.PresentationUrl = "http://www.apress.com/";
            // Device
            Device.ThisDevice.FriendlyName = "Attachment service device";
            Device.ThisDevice.FirmwareVersion = "demo";
            Device.ThisDevice.SerialNumber = "12345678";

            // Set this device property if you want to ignore this clients request
            Device.IgnorelocalClientRequest = false;

            // Start the device
            Device.Start();

            // Keep the device alive
            Thread.Sleep(Timeout.Infinite);
        }
    }
}
