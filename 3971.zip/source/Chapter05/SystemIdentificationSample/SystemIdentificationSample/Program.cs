﻿using System;
using Microsoft.SPOT;
using Microsoft.SPOT.Hardware;

namespace SystemIdentificationSample
{
    public class Program
    {
        public static void Main()
        {
            Debug.Print("Model: " + SystemID.Model);
            Debug.Print("Original Equipment Manufacturer (OEM): " + SystemID.OEM);
            Debug.Print("Stock Keeping Unit (SKU): " + SystemID.SKU);
        }
    }
}
