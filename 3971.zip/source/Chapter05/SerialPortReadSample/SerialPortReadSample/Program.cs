﻿using System;
using System.Text;
using System.Threading;
using Microsoft.SPOT;
using Microsoft.SPOT.Hardware;

namespace SerialPortReadSample
{
    public class Program
    {
        public static void Main()
        {
            SerialPort.Configuration config = new SerialPort.Configuration(SerialPort.Serial.COM1, SerialPort.BaudRate.Baud115200, false);
            SerialPort serialPort = new SerialPort(config);
            byte[] inBuffer = new byte[32];
            while (true)
            {
                int count = serialPort.Read(inBuffer, 0, inBuffer.Length, 0);
                if (count > 0) //minimum one byte read
                {
                    char[] chars = Encoding.UTF8.GetChars(inBuffer);
                    string str = new string(chars, 0, count);
                    Debug.Print(str);
                }
                Thread.Sleep(25); //give device time to sleep
            }
        }
    }
}
