﻿using System;
using System.Text;
using System.Threading;
using Microsoft.SPOT;
using Microsoft.SPOT.Hardware;

namespace SerialPortWriteSample
{
    public class Program
    {
        public static void Main()
        {
            SerialPort.Configuration config = new SerialPort.Configuration(SerialPort.Serial.COM1, SerialPort.BaudRate.Baud9600, false);
            SerialPort serialPort = new SerialPort(config);
            byte[] outBuffer = Encoding.UTF8.GetBytes("Hello World!\r\n");
            int i = 10;
            while (i-- > 0)
            {
                serialPort.Write(outBuffer, 0, outBuffer.Length);
                Thread.Sleep(500);
            }
            serialPort.Dispose();
            Thread.Sleep(Timeout.Infinite); //keeps the emulator running to see results
        }
    }
}
