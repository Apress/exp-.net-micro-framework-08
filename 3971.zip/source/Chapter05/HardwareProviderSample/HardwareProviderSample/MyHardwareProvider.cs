﻿using System;
using Microsoft.SPOT;
using Microsoft.SPOT.Hardware;

namespace HardwareProviderSample
{
    internal sealed class MyHardwareProvider : HardwareProvider
    {
        public override void GetSerialPins(SerialPort.Serial com, out Cpu.Pin rxPin, out Cpu.Pin txPin)
        {
            switch (com)
            {
                case SerialPort.Serial.COM1:
                    rxPin = Cpu.Pin.GPIO_Pin0;
                    txPin = Cpu.Pin.GPIO_Pin1;
                    break;
                case SerialPort.Serial.COM2:
                    rxPin = Cpu.Pin.GPIO_Pin2;
                    txPin = Cpu.Pin.GPIO_Pin3;
                    break;
                default:
                    rxPin = Cpu.Pin.GPIO_NONE;
                    txPin = Cpu.Pin.GPIO_NONE;
                    break;
            }
        }
    }
}
