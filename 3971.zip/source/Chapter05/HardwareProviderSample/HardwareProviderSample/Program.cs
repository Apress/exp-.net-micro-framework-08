﻿using System;
using Microsoft.SPOT;
using Microsoft.SPOT.Hardware;

namespace HardwareProviderSample
{
    public class Program
    {
        public static void Main()
        {
            HardwareProvider.Register(new MyHardwareProvider());

            SerialPort.Configuration config = new SerialPort.Configuration(SerialPort.Serial.COM1,
                                                                           SerialPort.BaudRate.Baud9600,
                                                                           false);
//            SerialPort serialPortA = new SerialPort(config);
//            SerialPort serialPortB = new SerialPort(config);

            SerialPort serialPortA = new SerialPort(config); //reserves Pin 0 und 1 for COM1
            OutputPort outputPort = new OutputPort(Cpu.Pin.GPIO_Pin1, false);

            Port.ReservePin(Cpu.Pin.GPIO_Pin10, true);
        }
    }
}
