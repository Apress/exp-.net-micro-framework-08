﻿using System;
using System.Text;
using System.Threading;
using Microsoft.SPOT;
using Microsoft.SPOT.Hardware;

namespace SerialPortWriteReadSample
{
    public class Program
    {
        public static void Main()
        {
            SerialPort.Configuration config = new SerialPort.Configuration(SerialPort.Serial.COM1,
                                                                           SerialPort.BaudRate.Baud115200,
                                                                           false);
            SerialPort serialPort = new SerialPort(config);
            byte[] outBuffer = Encoding.UTF8.GetBytes("All right?\r\n");
            byte[] inBuffer = new byte[2];
            while (true)
            {
                Debug.Print("Request data");
                serialPort.Write(outBuffer, 0, outBuffer.Length);
                int count = serialPort.Read(inBuffer, 0, 2, 5000);
                if (count == 2)
                {
                    Debug.Print("Received expected two bytes!");
                }
                else
                {
                    if (count == 0)
                        Debug.Print("No response!");
                    if(count == 1)
                        Debug.Print("Not enough bytes received!");
                }
                Debug.Print(string.Empty);
            }
        }
    }
}
