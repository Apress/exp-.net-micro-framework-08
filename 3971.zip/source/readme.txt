---------
Chapter 5
---------
To get the examples in this chapter running on real hardware, you need to change the pin numbers
in the code according to the device`s pin set. You can find the pin numbers in the documentation of your development board.
Most hardware sample code in this chapter is written particularly for the emulators of chapter 13.
To run the samples without real hardware, you need to built the emulator projects located in the directory for chapter 13 first.

---------
Chapter 9
---------
In order to store data permanently in flash memory (ExtendedWeakReferenceSample project), your device must support permanent storage in the flash memory.
For execution on an emulator, you need to first create the stand-alone sample emulator project,
EWRSampleEmulator, provided with the .NET Micro Framework SDK. When the emulator is
compiled, it is registered automatically, and after that, you can select it in the project properties
of a .NET Micro Framework application, as Emulator on the Micro Framework tab page. This emulator stores the contents of its flash memory into a file on termination and loads that file on startup.
Alternatively you can compile and use the PersistentFlashManagerComponent and PersistentFlashSampleEmulator of chapter 13.

----------
Chapter 11
----------
The WPF samples in this chapter rely on the pin-to-button mapping of the default Microsoft Emulator and Freescale i.MXS board. To run it on other hardware, you need to change the pin configuration of the GPIO input provider class.