﻿using System;
using Microsoft.SPOT;
using Microsoft.SPOT.Hardware;

namespace LocalTimeSample
{
    public class Program
    {
        public static void Main()
        {
            Debug.Print("Local Time: " + DateTime.Now.ToString());
            DateTime newLocalTime = new DateTime(2007, 1, 2, 3, 4, 5);
            Utility.SetLocalTime(newLocalTime);
            Debug.Print("New Local Time: " + DateTime.Now.ToString());
            Debug.Print("Time Zone: " + TimeZone.CurrentTimeZone.StandardName);
            Debug.Print("Local Time: " + DateTime.Now.ToString());
            ExtendedTimeZone.SetTimeZone(TimeZoneId.Berlin);
            Debug.Print("New Time Zone: " + TimeZone.CurrentTimeZone.StandardName);
            Debug.Print("Local Time: " + DateTime.Now.ToString());
        }
    }
}
