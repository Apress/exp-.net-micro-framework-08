﻿using System;
using Microsoft.SPOT;
using Microsoft.SPOT.Presentation;
using Microsoft.SPOT.Presentation.Media;

namespace CustomElementSample
{
    public class CustomElement : UIElement
    {
        public override void OnRender(DrawingContext dc)
        {
            base.OnRender(dc);
            dc.DrawEllipse(null, // brush: filling not supported
                           new Pen(Colors.Blue),   // pen
                           this.ActualWidth / 2,   // x
                           this.ActualHeight / 2,  // y
                           this.ActualWidth / 2,   // x radius
                           this.ActualHeight / 2); // y radius
        }
    }
}
