﻿using System;
using System.Threading;
using Microsoft.SPOT;
using Microsoft.SPOT.Hardware;
using Microsoft.SPOT.Presentation.Media;

namespace ScaledImageSample
{
    public class Program
    {
        public static void Main()
        {
            ScreenMetrics metrics = ScreenMetrics.GetMetrics();
            Bitmap bmp = new Bitmap(metrics.Width, metrics.Height);
            Bitmap soccerBall = Resources.GetBitmap(Resources.BitmapResources.SoccerBall);
            bmp.StretchImage(100, 50,            // destination coordinates
                          soccerBall,            // source image
                          soccerBall.Width / 2,  // half width
                          soccerBall.Height * 2, // double height
                          Bitmap.OpacityOpaque); // opacity
            bmp.Flush();
            Thread.Sleep(-1); //do not terminate app to see result
        }

    }
}
