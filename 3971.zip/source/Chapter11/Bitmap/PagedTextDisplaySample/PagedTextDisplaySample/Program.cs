﻿using System;
using System.Threading;
using Microsoft.SPOT;
using Microsoft.SPOT.Hardware;
using Microsoft.SPOT.Presentation.Media;

namespace PagedTextDisplaySample
{
    public class Program
    {
        public static void Main()
        {
            ScreenMetrics metrics = ScreenMetrics.GetMetrics();
            Bitmap bmp = new Bitmap(metrics.Width, metrics.Height);
            Font font = Resources.GetFont(Resources.FontResources.NinaB);
            string text = "There is another overload of the DrawTextInRect " +
                          "method. That method comes along with reference " +
                          "parameters for the input string and the x and y " +
                          "drawing positions. After drawing text, the " +
                          "method updates the x and y positions to tell you " +
                          "where on the display the drawing of the text " +
                          "finished. This allows you to draw parts of the text " +
                          "with a different color or font. Also, if the method " +
                          "cannot display the complete text within the specified " +
                          "rectangle, it returns the remaining text. " +
                          "In this case, the method returns false to indicate " +
                          "that there is some text left that could not " +
                          "displayed. This enables you to build up a display " +
                          "to show text over mulitple pages."; 
            bool completed;
            do
            {
                int x = 0;
                int y = 0;
                //draw frame around text and clear old contents
                bmp.DrawRectangle(Color.White, 1, 20, 20, 150, 150, 0, 0, Color.Black, 0, 0, Color.Black, 0, 0, Bitmap.OpacityOpaque);
                completed = bmp.DrawTextInRect(
                                     ref text,
                                     ref x, ref y, // x and y text position
                                     20, 20,       // x and y (rectangle top left)
                                     150, 150,     // width and height of rectangle
                                     Bitmap.DT_AlignmentLeft | Bitmap.DT_WordWrap,
                                     Color.White,  // color
                                     font);        // font
                bmp.Flush();
                Thread.Sleep(3000); //display each page for three seconds
            } while (!completed);
            Thread.Sleep(-1);
        }
    }
}
