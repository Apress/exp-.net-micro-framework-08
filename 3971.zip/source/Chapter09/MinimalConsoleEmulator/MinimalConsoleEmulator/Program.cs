﻿using System;
using Microsoft.SPOT.Emulator;

namespace MinimalConsoleEmulator
{
    class Program
    {
        static void Main()
        {
            new Emulator().Start();
        }
    }
}